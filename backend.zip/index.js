
const express = require('express');
const dotenv = require('dotenv');
const { GoogleGenerativeAI } = require('@google/generative-ai');
const cors = require('cors');

dotenv.config();

const app = express();
const port = process.env.PORT || 3001;

app.use(cors());
app.use(express.json());

const genAI = new GoogleGenerativeAI(process.env.API_KEY);

app.post('/api/genai', async (req, res) => {
  try {
    const { model, prompt } = req.body;
    const generationConfig = req.body.generationConfig || {};
    const safetySettings = req.body.safetySettings || [];

    const generativeModel = genAI.getGenerativeModel({ model });

    const result = await generativeModel.generateContent(prompt, {
      ...generationConfig,
      safetySettings,
    });

    const response = await result.response;
    res.json(response);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'An error occurred while communicating with the AI service.' });
  }
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
